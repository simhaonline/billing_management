<?php require "../config.tpl";
    require "../".MODEL."categoryModel.inc";
    require "../".CONTROLLER.'categoryController.inc';
    $category = new categoryModel();
    $c = new categoryController();
    if($_SERVER['REQUEST_METHOD']=="POST"){
        if(isset($_POST['txtName'])){
            $category->setId(sanitize($_POST['txtId']));
            $category->setName(sanitize($_POST['txtName']));
            $c->doSave($category);
            if($category->getMessage()==="success"){
                echo "1";
            }else if($category->getMessage()==="updated"){
                echo "2";
            }else{
                echo getAlertDiv($category->getMessage());
            }
        }else{
            if(isset($_POST['ID'])){
                echo $c->getCategoryToEdit($category,$_POST['ID']);
            }else if(isset($_POST['DELETE_ID'])){
                echo $c->deleteCategory($_POST['DELETE_ID']);
            }
        }
    }else{
        $category->setLimit(sanitize($_GET['LIMIT']));
        $category->setOrderBy(sanitize($_GET['ORDER']));
        $category->setSearch(sanitize($_GET['SEARCH']));
        ?>
        <table class="table table-light table-striped">
            <tr>
                <th>S. No</th>
                <th>Category</th>
                <th>Action</th>
            </tr>
            <?php
                echo $c->getAll($category);
            ?>
        </table>
<?php
    }
?>