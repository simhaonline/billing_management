<?php   require "../config.tpl";
        require_once "../".MODEL."userModel.inc";
        require_once "../".CONTROLLER."userController.inc";
        $model= new userModel();
        $c = new userController();
        echo $c->getAllData($model);
?>