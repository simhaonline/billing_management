<?php require "../config.tpl";
    require_once "../".MODEL."productModel.inc";
    require_once "../".CONTROLLER."productController.inc";
    $model = new productModel();
    $c = new productController();
    if($_SERVER['REQUEST_METHOD']=="POST"){
        if(isset($_POST['ddlCategory'])){
            $model->setId(sanitize($_POST['txtId']));
            $model->setSubCatId(sanitize($_POST['ddlSubCategory']));
            $model->setName(sanitize($_POST['txtName']));
            $model->setDescription(sanitize($_POST['txtDescription']));
            $model->setPrice(sanitize($_POST['txtPrice']));
            $model->setImage("image");
            $c->doSave($model);
            if($model->getMessage()==="success"){
                echo "1";
            }else if($model->getMessage()==="updated"){
                echo "2";
            }else{
                echo getAlertDiv($model->getMessage());
            }
        }else{
            if(isset($_POST['ID'])){
                $model->setId(sanitize($_POST['ID']));
                echo $c->getProductToEdit($model);
            }else if(isset($_POST['VIEW_ID'])){
                $model->setId(sanitize($_POST['VIEW_ID']));
                echo $c->viewProduct($model);
            }
        }
    }else{
        if(isset($_GET['CAT_ID'])){
            echo getSubCategory(sanitize($_GET['CAT_ID']));
        }else{
            $model->setLimit($_GET['LIMIT']);
            $model->setOrderBy($_GET['ORDER']);
            $model->setSearch($_GET['SEARCH']);
            $model->setSubCatId($_GET['SUB_CAT_ID']);
        ?>
            <table class="table table-striped table-light">
                <tr>
                    <th>S. No</th>
                    <th>Sub Category</th>
                    <th>Product</th>
                    <th>Action</th>
                </tr>
                <?php
                    echo $c->getAllProducts($model);
                ?>
            </table>
<?php
        }
    }
?>