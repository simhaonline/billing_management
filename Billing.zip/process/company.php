<?php   require "../config.tpl";
    require "../".MODEL."companyModel.inc";
    require "../".CONTROLLER."companyController.inc";
    $company = new companyModel();
    $c = new companyController();
    if($_SERVER['REQUEST_METHOD']=="POST"){
        $company->setId(sanitize($_POST["txtId"]));
        $company->setName(sanitize($_POST["txtName"]));
        $company->setMobile(sanitize($_POST["txtMobile"]));
        $company->setEmail(sanitize($_POST["txtEmail"]));
        $company->setAddressLine1(sanitize($_POST["txtAddressLine1"]));
        $company->setAddressLine2(sanitize($_POST["txtAddressLine2"]));
        $company->setLandmark(sanitize($_POST["txtLandmark"]));
        $company->setDistrict(sanitize($_POST["txtDistrict"]));
        $company->setState(sanitize($_POST["txtState"]));
        $company->setCountry(sanitize($_POST["txtCountry"]));
        $company->setPin(sanitize($_POST["txtPin"]));
        $company->setGstin(sanitize($_POST["txtGst"]));
        $company->setLogo("logo");
        $c->doSave($company);
        if($company->getMessage()=="success"){
            echo "1";
        }else if($company->getMessage()=="updated"){
            echo "2";
        }else{
            echo getAlertDiv($company->getMessage());
        }
    }else{
        echo $c->getDetails($company);
    }
?>