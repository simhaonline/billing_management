<?php require ("../config.tpl");
    if($_SERVER['REQUEST_METHOD']=="POST"){
        require_once "../".MODEL.'userModel.inc';
        require_once "../".CONTROLLER.'userController.inc';
        $user = new userModel();
        $uc = new userController();
        $user->setUsername(sanitize($_POST['txtUsername']));
        $user->setPassword(sanitize($_POST['txtPassword']));
        $user->setCaptcha(sanitize($_POST['txtCaptcha']));
        $user->setCsrf(sanitize($_POST['txtCsrf']));
        $uc->login($user);
        if($user->getMessage()==="success"){
            echo "1";
        }else{
            echo getAlertDiv($user->getMessage());
        }
    }
?>