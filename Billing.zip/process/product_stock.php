<?php require "../config.tpl";
    require_once "../".MODEL."productStockModel.inc";
    require_once "../".CONTROLLER."productStockController.inc";
    $model = new productStockModel();
    $c = new productStockController();
    if($_SERVER['REQUEST_METHOD']=="POST"){
        if(isset($_POST['ddlCategory'])){
            $model->setId(sanitize($_POST['txtId']));
            $model->setProductId(sanitize($_POST['ddlProduct']));
            $model->setStock(sanitize($_POST['txtStock']));
            $c->doSave($model);
            if($model->getMessage()==="success"){
                echo "1";
            }else if($model->getMessage()==="updated"){
                echo "2";
            }else{
                echo getAlertDiv($model->getMessage());
            }
        }else{
            if(isset($_POST['ID'])){
                echo $c->getStockToEdit(sanitize($_POST['ID']));
            }else if(isset($_POST['CAT_ID'])){
                echo getSubCategory(sanitize($_POST['CAT_ID']));
            }else if(isset($_POST['SUB_CAT_ID'])){
                echo getProducts(sanitize($_POST['SUB_CAT_ID']));
            }
        }
    }else{
            $model->setLimit(sanitize($_GET['LIMIT']));
            $model->setOrderBy(sanitize($_GET['ORDER']));
            $model->setSearch(sanitize($_GET['SEARCH']));
            $model->setProductId(sanitize($_GET['PRODUCT_ID']));
        ?>
        <table class="table table-striped table-light">
            <tr>
                <th>S. No</th>
                <th>Product</th>
                <th>Stock</th>
                <th>Action</th>
            </tr>
            <?php
                echo $c->getAllProductStock($model);
            ?>
        </table>
<?php
    }
?>