<?php require "../config.tpl";
    require_once "../".MODEL."orderModel.inc";
    require_once "../".CONTROLLER."orderController.inc";
    $model = new orderModel();
    $c = new orderController();
if($_SERVER['REQUEST_METHOD']=="POST"){
    $d = array();
        if(isset($_POST['ddlCustomer'])){
            $i=0;
           foreach($_POST['ddlProducts'] as $k => $v){
               $x["product_".$i]=array(
                 "pid"=>$v,
                 "quantity"=>$_POST['txtQuantity'][$i],
                 "rate"=>$_POST['txtRate'][$i],
                 "amount"=>$_POST['txtAmount'][$i]
               );
               $i++;
           }
            array_push($d,$x);
            $model->setGrossAmount($_POST['txtGrossAmount']);
            $model->setVat($_POST['txtGst']);
            $model->setDiscount($_POST['txtDiscount']);
            $model->setTotalAmount($_POST['txtNet']);
            $model->setStatus("0");
            $model->setCustId($_POST['ddlCustomer']);
            $c->orderIt($model,$d);
        }else{
            if(isset($_POST['PROD_ID'])){
                echo $c->getProductData($_POST['PROD_ID']);
            }
        }
}else {
    $count = $_GET['COUNT'];
    ?>
    <tr id="<?php echo "tr_" . $count; ?>">
        <td>
            <select name="ddlProducts[]" id="product_<?php echo $count; ?>" class="form-control"
                    onchange="javascript: getProductData(<?php echo $count;?>)">
                <?php
                echo getAllProductsForOrder();
                ?>
            </select>
        </td>
        <td>
            <input type="text" name="txtQuantity[]" id="qty_<?php echo $count; ?>" class="form-control" onkeyup="getTotal(<?php echo $count;?>)"/>
        </td>
        <td>
            <input type="text" name="txtRate[]" id="rate_<?php echo $count; ?>" class="form-control" readonly/>
        </td>
        <td>
            <input type="text" name="txtAmount[]" id="amount_<?php echo $count; ?>" class="form-control disabled" readonly/>
        </td>
        <td>
        <span id="btnRemoveNew" onclick="javascript: removeTr(<?php echo $count; ?>)"
              class="btn btn-sm btn-outline-danger">
            <i class="fa fa-times"></i>
        </span>
        </td>
    </tr>
    <?php
}
?>
