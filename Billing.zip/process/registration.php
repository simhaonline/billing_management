<?php require "../config.tpl";
      require_once "../".MODEL."registerModel.inc";
      require_once "../".CONTROLLER."registerController.inc";
      $user = new registerModel();
      $c = new registerController();
      if($_SERVER['REQUEST_METHOD']=="POST"){
          if(isset($_POST['txtName'])){
              $user->setId(sanitize($_POST['txtId']));
              $user->setName(sanitize($_POST['txtName']));
              $user->setEmail(sanitize($_POST['txtEmail']));
              $user->setMobile(sanitize($_POST['txtMobile']));
              $user->setUsername(sanitize($_POST['txtUsername']));
              $user->setRole(sanitize($_POST['txtRole']));
              $user->setStatus(sanitize($_POST['txtStatus']));
              $user->setImage("userImage");
              $c->doSave($user);
              if($user->getMessage()==="success"){
                  echo "1";
              }else if($user->getMessage()==="updated"){
                  echo "2";
              }else{
                  echo getAlertDiv($user->getMessage());
              }
          }else{
              if(isset($_POST['ID'])){
                  $user->setId(sanitize($_POST['ID']));
                echo $c->getUserToEdit($user);
              }
          }
      }else{
          $user->setLimit(sanitize($_GET['LIMIT']));
          $user->setOrderBy(sanitize($_GET['ORDER']));
          $user->setSearch(sanitize($_GET['SEARCH']));
          $user->setRole(sanitize($_GET['ROLE']));
          $user->setStatus(sanitize($_GET['STATUS']));
        ?>
          <table class="table table-light table-striped">
              <tr>
                  <th>S. No</th>
                  <th>Name</th>
                  <th>Role</th>
                  <th>Action</th>
              </tr>
              <?php
                echo $c->getAllUsers($user);
              ?>
          </table>
<?php
      }
?>