<?php require_once "../config.tpl";
      require_once "../".MODEL."changePasswordModel.inc";
      require_once "../".CONTROLLER."userController.inc";
      $model = new changePasswordModel();
      $c = new userController();
      if($_SERVER['REQUEST_METHOD']=="POST"){
          $model->setId(getUserId($_SESSION[AUTH_SESSION]));
          $model->setOPassword(sanitize($_POST['OLD_PASSWORD']));
          $model->setPassword(sanitize($_POST['PASSWORD']));
          $model->setCPassword(sanitize($_POST['C_PASSWORD']));
          $c->changePassword($model);
          if($model->getMessage()==="success"){
              echo "1";
          }else{
              echo getAlertDiv($model->getMessage());
          }
      }
?>
