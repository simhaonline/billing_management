<?php require "../config.tpl";
    require "../".MODEL."subCategoryModel.inc";
    require "../".CONTROLLER."subCategoryController.inc";
    $model = new subCategoryModel();
    $c = new subCategoryController();
    if($_SERVER['REQUEST_METHOD']=="POST"){
        if(isset($_POST['txtName'])){
            $model->setId(sanitize($_POST['txtId']));
            $model->setName(sanitize($_POST['txtName']));
            $model->setCategoryId(sanitize($_POST['ddlCategory']));
            $c->doSave($model);
            if($model->getMessage()=="success"){
                echo "1";
            }else if($model->getMessage()=="updated"){
                echo "2";
            }else{
                echo getAlertDiv($model->getMessage());
            }
        }else{
            if(isset($_POST['ID'])){
                echo $c->getSubCategoryToEdit($model,$_POST['ID']);
            }
        }
    }else{
            if(isset($_GET['VIEW_ID'])){
                echo $c->getSubcategory($model,$_GET['VIEW_ID']);
            }else{
            $model->setLimit(sanitize($_GET['LIMIT']));
            $model->setOrderBy(sanitize($_GET['ORDER']));
            $model->setSearch(sanitize($_GET['SEARCH']));
            $model->setCategoryId(sanitize($_GET['CAT_ID']));
        ?>
        <table class="table table-striped table-light">
            <tr>
                <th>S. No</th>
                <th>Category</th>
                <th>Sub Category</th>
                <th>Action</th>
            </tr>
            <?php
                echo $c->retrieveAll($model);
            ?>
        </table>
<?php
            }
    }
?>