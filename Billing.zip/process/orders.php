<?php require "../config.tpl";
      require_once "../".MODEL."orderModel.inc";
      require_once "../".CONTROLLER."orderController.inc";
      $m = new orderModel();
      $c = new orderController();
    if($_SERVER['REQUEST_METHOD']=="POST"){
        $m->setDiscount(sanitize($_POST['DISCOUNT']));
        $m->setStatus(sanitize($_POST['STATUS1']));
        $m->setId(sanitize($_POST['PDID']));
        $c->nowEdit($m);
        if($m->getMessage()==="success"){
            echo "1";
        }else{
            echo getAlertDiv($m->getMessage());
        }
    }else{
        if(isset($_GET['EDIT_ID'])){
            echo $c->editOrder(sanitize($_GET['EDIT_ID']));
        }elseif(isset($_GET['VIEW_ID'])){
            echo $c->viewOrder(sanitize($_GET['VIEW_ID']));
        }else{
            $m->setLimit(sanitize($_GET['LIMIT']));
            $m->setOrderBy(sanitize($_GET['ORDER']));
            $m->setSearch(sanitize($_GET['SEARCH']));
            $m->setCustId(sanitize($_GET['CUST_ID']));
            $m->setStatus(sanitize($_GET['STATUS']));
        ?>
        <table class="table table-light table-striped">
            <tr>
                <th>S. No</th>
                <th>Bill Number</th>
                <th>Customer</th>
                <th>Order Amount</th>
                <th>Discount</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
            <?php
                echo $c->getAllOrders($m);
            ?>
        </table>
<?php
        }
    }
?>