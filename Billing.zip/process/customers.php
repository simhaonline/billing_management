<?php require "../config.tpl";
    require_once "../".MODEL."customerModel.inc";
    require_once "../".CONTROLLER."customerController.inc";
    $model = new customerModel();
    $c = new customerController();
    if($_SERVER['REQUEST_METHOD']=="POST"){
        if(isset($_POST['txtName'])){
            $model->setId(sanitize($_POST['txtId']));
            $model->setName(sanitize($_POST['txtName']));
            $model->setMobile(sanitize($_POST['txtMobile']));
            $model->setEmail(sanitize($_POST['txtEmail']));
            $model->setAddress(sanitize($_POST['txtAddress']));
            $c->saveCustomer($model);
            if($model->getMessage()==="success"){
                echo "1";
            }else if($model->getMessage()==="updated"){
                echo "2";
            }else{
                echo getAlertDiv($model->getMessage());
            }
        }else{
            if(isset($_POST['ID'])){
                $model->setId(sanitize($_POST['ID']));
                echo $c->getCustomerToEdit($model);
            }else if(isset($_POST['VIEW_ID'])){
                $model->setId(sanitize($_POST['VIEW_ID']));
                echo $c->viewCustomer($model);
            }
        }
    }else{
        $model->setLimit(sanitize($_GET['LIMIT']));
        $model->setOrderBy(sanitize($_GET['ORDER']));
        $model->setSearch(sanitize($_GET['SEARCH']));
?>
        <table class="table table-light table-striped">
            <tr>
                <th>S. No</th>
                <th>Name</th>
                <th>Email</th>
                <th>Mobile</th>
                <th>Action</th>
            </tr>
<?php
        echo $c->getAllCustomers($model);
?>
        </table>
<?php
    }
?>