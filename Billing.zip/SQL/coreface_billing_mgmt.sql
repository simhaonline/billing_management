-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 09, 2019 at 01:58 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coreface_billing_mgmt`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `dated` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `companydetails`
--

CREATE TABLE `companydetails` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `addressLine1` varchar(100) DEFAULT NULL,
  `addressLine2` varchar(100) DEFAULT NULL,
  `landmark` varchar(100) DEFAULT NULL,
  `district` varchar(30) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `pin` int(6) DEFAULT NULL,
  `gstin` varchar(20) DEFAULT NULL,
  `logo` varchar(100) DEFAULT NULL,
  `dated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `address` text,
  `mobileNumber` bigint(20) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `dated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `navigation`
--

CREATE TABLE `navigation` (
  `id` int(11) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `link` varchar(150) DEFAULT NULL,
  `icon` varchar(30) DEFAULT NULL,
  `dated` datetime DEFAULT CURRENT_TIMESTAMP,
  `orderBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `navigation`
--

INSERT INTO `navigation` (`id`, `title`, `link`, `icon`, `dated`, `orderBy`) VALUES
(1, 'Dashboard', 'Dashboard/', 'fa-dashboard', '2019-08-24 03:13:00', 1),
(2, 'Manage Details', 'Manage_Details/', 'fa-building-o', '2019-08-24 17:08:46', 2),
(3, 'Manage Categories', 'Manage_Categories/', 'fa-cubes', '2019-08-24 17:08:46', 3),
(4, 'Manage Sub Categories', 'Manage_Sub_Categories/', 'fa-link', '2019-08-24 17:09:23', 4),
(5, 'Manage Products', 'Manage_Products/', 'fa-cube', '2019-08-24 17:09:49', 5),
(6, 'Manage Stock', 'Manage_Stock/', 'fa-external-link', '2019-08-24 17:10:44', 6),
(7, 'Manage Users', 'Manage_Users/', 'fa-user-plus', '2019-08-24 17:10:44', 9),
(9, 'Manage Customers', 'Manage_Customers/', 'fa-user-o', '2019-08-30 19:33:22', 7),
(10, 'Manage Orders', 'Manage_Orders/', 'fa-rupee', '2019-09-08 09:34:39', 8);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `billNo` varchar(20) DEFAULT NULL,
  `customerId` int(11) DEFAULT NULL,
  `grossAmount` int(11) DEFAULT NULL,
  `vat` int(11) DEFAULT NULL,
  `totalAmount` int(11) DEFAULT NULL,
  `discount` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `dated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `order_item`
--

CREATE TABLE `order_item` (
  `id` int(11) NOT NULL,
  `orderId` int(11) DEFAULT NULL,
  `productId` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `amount` int(11) NOT NULL,
  `dated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `productName` varchar(100) DEFAULT NULL,
  `subCategoryId` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL,
  `description` text,
  `dated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `product_stock`
--

CREATE TABLE `product_stock` (
  `id` int(11) NOT NULL,
  `productId` int(11) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `dated` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `roleName` varchar(20) DEFAULT NULL,
  `fullName` varchar(20) NOT NULL,
  `dated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `roleName`, `fullName`, `dated`) VALUES
(1, 'Admin', 'Administrator', '2019-08-24 17:05:41'),
(2, 'User', 'User', '2019-08-24 17:05:41');

-- --------------------------------------------------------

--
-- Table structure for table `sub_categories`
--

CREATE TABLE `sub_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `categoryId` int(11) DEFAULT NULL,
  `dated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `usernav`
--

CREATE TABLE `usernav` (
  `id` int(11) NOT NULL,
  `navId` int(11) DEFAULT NULL,
  `roleId` int(11) DEFAULT NULL,
  `dated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `usernav`
--

INSERT INTO `usernav` (`id`, `navId`, `roleId`, `dated`) VALUES
(1, 1, 1, '2019-08-24 17:13:24'),
(2, 2, 1, '2019-08-24 17:13:24'),
(3, 3, 1, '2019-08-24 17:13:45'),
(4, 4, 1, '2019-08-24 17:13:45'),
(5, 5, 1, '2019-08-24 17:14:03'),
(6, 6, 1, '2019-08-24 17:14:03'),
(7, 7, 1, '2019-08-24 17:14:18'),
(9, 3, 2, '2019-08-24 23:10:51'),
(10, 4, 2, '2019-08-24 23:11:21'),
(11, 5, 2, '2019-08-24 23:11:38'),
(12, 1, 2, '2019-08-24 23:11:38'),
(13, 6, 2, '2019-08-24 23:12:04'),
(15, 9, 1, '2019-08-30 19:34:00'),
(16, 9, 2, '2019-08-30 19:34:00'),
(17, 10, 1, '2019-09-08 09:35:26'),
(18, 10, 2, '2019-09-08 09:35:26');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(300) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `status` int(1) NOT NULL,
  `image` varchar(200) NOT NULL,
  `roleId` int(11) DEFAULT NULL,
  `dated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `name`, `email`, `mobile`, `status`, `image`, `roleId`, `dated`) VALUES
(1, 'admin', 'VGxScmVVOUhWWGhOUkVac1QwUm5NVTVVVVhwT01ra3dXa1JSTlUxRVNYcFBSR04zVGtSS2JWbDZRVDA9', 'Abdul Muazzam', 'admin@corefacetechnologies.com', '8825011191', 1, 'images/muazzam.jpg', 1, '2019-08-24 17:06:33'),
(2, 'muazzam', 'VGxScmVVOUhWWGhOUkVac1QwUm5NVTVVVVhwT01ra3dXa1JSTlUxRVNYcFBSR04zVGtSS2JWbDZRVDA9', 'Muazzam Manzoor', 'muazzam@corefacetechnologies.com', '8825011191', 1, '', 2, '2019-08-24 23:09:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `companydetails`
--
ALTER TABLE `companydetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `navigation`
--
ALTER TABLE `navigation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_custId` (`customerId`);

--
-- Indexes for table `order_item`
--
ALTER TABLE `order_item`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_orderId` (`orderId`),
  ADD KEY `f_pid` (`productId`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_subcat` (`subCategoryId`);

--
-- Indexes for table `product_stock`
--
ALTER TABLE `product_stock`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_productId` (`productId`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_catId` (`categoryId`);

--
-- Indexes for table `usernav`
--
ALTER TABLE `usernav`
  ADD PRIMARY KEY (`id`),
  ADD KEY `roleId` (`roleId`),
  ADD KEY `fk_nav` (`navId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_role` (`roleId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `companydetails`
--
ALTER TABLE `companydetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `navigation`
--
ALTER TABLE `navigation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_item`
--
ALTER TABLE `order_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_stock`
--
ALTER TABLE `product_stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sub_categories`
--
ALTER TABLE `sub_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `usernav`
--
ALTER TABLE `usernav`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_custId` FOREIGN KEY (`customerId`) REFERENCES `customers` (`id`);

--
-- Constraints for table `order_item`
--
ALTER TABLE `order_item`
  ADD CONSTRAINT `f_pid` FOREIGN KEY (`productId`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `fk_orderId` FOREIGN KEY (`orderId`) REFERENCES `orders` (`id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_subcat` FOREIGN KEY (`subCategoryId`) REFERENCES `sub_categories` (`id`);

--
-- Constraints for table `product_stock`
--
ALTER TABLE `product_stock`
  ADD CONSTRAINT `fk_productId` FOREIGN KEY (`productId`) REFERENCES `products` (`id`);

--
-- Constraints for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD CONSTRAINT `fk_catId` FOREIGN KEY (`categoryId`) REFERENCES `categories` (`id`);

--
-- Constraints for table `usernav`
--
ALTER TABLE `usernav`
  ADD CONSTRAINT `fk_nav` FOREIGN KEY (`navId`) REFERENCES `navigation` (`id`),
  ADD CONSTRAINT `usernav_ibfk_1` FOREIGN KEY (`roleId`) REFERENCES `roles` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_role` FOREIGN KEY (`roleId`) REFERENCES `roles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
