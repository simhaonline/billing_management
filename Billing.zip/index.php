<?php require "config.tpl"; require LIB."routing.tpl"; $rout = new routing(); ?>

