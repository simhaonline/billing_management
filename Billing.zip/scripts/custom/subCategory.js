$(document).ready(function(){
   $('#subCatForm').on('submit',function(e){
      e.preventDefault();
      $.ajax({
         url: "process/subcategory.php",
         type:"POST",
         data: new FormData(this),
         processData: false,
         contentType: false,
         beforeSend: function(){
             $('#loader').show();
         },
         success: function(s){
             s = $.trim(s);
             if(s=="1"){
                $('#error').html("<p class='alert alert-success'>Successfully Saved!</p>");
                subCatForm.reset();
                setTimeout(function(){
                    $('#error').html("");
                },1500);
             }else if(s=="2"){
                 $('#error').html("<p class='alert alert-success'>Successfully Updated!</p>");
                 subCatForm.reset();
                 $('#txtId').val("");
                 $('#btnSubCat').val("Save");
                 setTimeout(function(){
                     $('#error').html("");
                 },1500);
             }else{
                 $('#error').html(s);
             }
         },
         complete: function(){
             $('#loader').hide();
             loadAllSubcategories();
         }
      });
   });
    loadAllSubcategories();
});
function loadAllSubcategories(){
    $.ajax({
       url:"process/subcategory.php",
       type: "GET",
       data:{
           LIMIT: $('#txtLimit').val(),
           ORDER: $('#txtOrder').val(),
           SEARCH: $('#txtSearch').val(),
           CAT_ID: $('#txtCategory').val()
       },
       beforeSend: function(){
          $('#ldr').show();
        },
       success:function(s){
           $('#listSubcategories').html(s);
       },
       complete: function(){
           $('#ldr').hide();
       }
    });
}
function editSubCategory(id){
    $.ajax({
       url: "process/subcategory.php",
       type: "POST",
       data:{ID:id},
       dataType: "JSON",
       success: function(s){
           $('#txtId').val(s.id);
           $('#ddlCategory').val(s.categoryId);
           $('#txtName').val(s.name);
           $('#btnSubCat').val("Update");
       }
    });
}
function viewSubCategory(id){
    $('#subcategoryModal').modal();
    $.ajax({
       url: "process/subcategory.php",
       type: "GET",
       data: {VIEW_ID:id},
       dataType: "JSON",
       success: function(s){
            $('#subCatName').text(s.name);
            $('#CatName').text(s.catName);
            $('#date').text(s.date);
            $('#time').text(s.time);
       }
    });
}