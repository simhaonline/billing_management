$(document).ready(function(){
    $('#stockForm').on('submit',function(e){
       e.preventDefault();
       $.ajax({
          url: "process/product_stock.php",
          type: "POST",
          data: new FormData(this),
          processData: false,
          contentType: false,
          beforeSend: function(){
           $('#loader').show();
          },
          success: function(s){
            s = $.trim(s);
            if(s=="1"){
                $('#error').html("<p class='alert alert-success'>Successfully Saved!</p>");
                stockForm.reset();
                setTimeout(function(){
                    $('#error').html("");
                },1500);
            }else if(s=="2"){
                $('#error').html("<p class='alert alert-success'>Successfully Updated!</p>");
                stockForm.reset();
                $('#txtId').val("");
                $('#btnStock').val("Save");
                setTimeout(function(){
                    $('#error').html("");
                },1500);
            }else{
                $('#error').html(s);
            }
          },
          complete: function(){
              $('#loader').hide();
              loadAllProducts();
          }
       });
    });
    $('#ddlCategory').on('change',function(){
       var catId = $(this).val();
       subCategories(catId,"top");
   });
    $('#ddlSubCategory').on('change',function(){
      loadProducts($(this).val(),"top");
   });
    $('#txtCategory').on('change',function(){
        var catId = $(this).val();
        subCategories(catId,"bottom");
    });
    $('#txtSubCategory').on('change',function(){
        loadProducts($(this).val(),"bottom");
    });
    loadAllProducts();
});
function subCategories(catId,position){
    $.ajax({
       url: "process/product_stock.php",
       type: "POST",
       data:{CAT_ID:catId},
       success: function(s){
           if(position=="top"){
               $('#ddlSubCategory').html(s).change();
           }else{
                $('#txtSubCategory').html(s).change();
           }
       }
    });
}
function loadProducts(subCatId,position){
    $.ajax({
       url: "process/product_stock.php",
       type: "POST",
       data: {SUB_CAT_ID:subCatId},
       success: function(s){
           if(position=="top"){
               $('#ddlProduct').html(s);
           }else{
               $('#txtProduct').html(s);
           }
       }
    });
}
function loadAllProducts(){
    $.ajax({
        url: "process/product_stock.php",
        type: "GET",
        data:{
            LIMIT: $('#txtLimit').val(),
            ORDER: $('#txtOrder').val(),
            SEARCH: $('#txtSearch').val(),
            PRODUCT_ID: $('#txtProduct').val()
        },
        beforeSend: function(){
          $('#ldr').show();
        },
        success: function(s){
            $('#listStock').html(s);
        },
        complete: function(){
            $('#ldr').hide();
        }
    });
}
function editStock(id){
    $.ajax({
        url: "process/product_stock.php",
        type: "POST",
        data:{ID:id},
        dataType: "JSON",
        success:function (s) {
            $('#txtId').val(s.id);
            $('#txtStock').val(s.stock);
            $('#btnStock').val("Update");
            setTimeout(function(){
                $('#ddlCategory').val(s.catId).change();
                setTimeout(function(){
                    $('#ddlSubCategory').val(s.SubCatId).change();
                    setTimeout(function(){
                        $('#ddlProduct').val(s.productId);
                    },100);
                },100);
            },100);
        }
    });
}