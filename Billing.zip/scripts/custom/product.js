$(document).ready(function(){
    $('#productForm').on('submit',function(e){
        e.preventDefault();
        for(instance in CKEDITOR.instances){
            CKEDITOR.instances[instance].updateElement();
        }
        $.ajax({
           url: "process/product.php",
           type: "POST",
           data: new FormData(this),
           processData: false,
           contentType: false,
           beforeSend: function () {
               $('#loader').show();
           },
           success: function(s){
               s = $.trim(s);
               if(s=="1"){
                   $('#error').html("<p class='alert alert-success'>Successfully Saved!</p>");
                   productForm.reset();
                   setTimeout(function(){
                       $('#error').html("");
                   },1500);
                   $('#ddlCategory').change();
                   resetCkEditor();
               }else if(s=="2"){
                   $('#error').html("<p class='alert alert-success'>Successfully Updated!</p>");
                   productForm.reset();
                   $('#imageLogo').removeAttr("src").hide();
                   $('#txtId').val("");
                   $('#btnProduct').val("Save");
                   setTimeout(function(){
                       $('#error').html("");
                   },1500);
                   $('#ddlCategory').change();
                   resetCkEditor();
               }else{
                   $('#error').html(s);
               }
           },
           complete: function(){
               $('#loader').hide();
               loadAllProducts();
           }
        });
    });
   $('#ddlCategory').on("change",function () {
        categories($(this).val(),"top");
   });
   $('#txtCategory').on('change',function(){
       categories($(this).val(),"bottom");
   });
    loadAllProducts();
});
function categories(catId,position){
    $.ajax({
        url: "process/product.php",
        type:"GET",
        data:{CAT_ID:catId},
        beforeSend: function(){
            if(position=="top"){
                $('#loader').show();
                $('#ddlSubCategory').html("<option value=''>Loading...</option>");
            }else{
                $('#ldr').show();
                $('#txtSubCategory').html("<option value=''>Loading...</option>");
            }
        },
        success: function(s){
            if(position=="top"){
                $('#ddlSubCategory').html(s);
            }else{
                $('#txtSubCategory').html(s);
            }
        },
        complete: function(){
            $('#loader').hide();
            $('#ldr').hide();
        }

    });
}
function loadAllProducts(){
    $.ajax({
       url: "process/product.php",
       type: "GET",
       data:{
           LIMIT: $('#txtLimit').val(),
           ORDER: $('#txtOrder').val(),
           SEARCH: $('#txtSearch').val(),
           SUB_CAT_ID: $('#txtSubCategory').val()
       },
       beforeSend: function(){
           $('#ldr').show();
       },
       success: function(s){
           $('#listProducts').html(s);
       },
       complete: function () {
           $('#ldr').hide();
       }
    });
}
function editProduct(id){
    $.ajax({
       url: "process/product.php",
       type: "POST",
       data:{ID:id},
       dataType: "JSON",
       success: function(s){
           if(s.image!=""){
                $('#imageLogo').attr('src',s.image);
           }else{
               $('#imageLogo').hide();
           }
           $('#ddlCategory').val(s.catId).change();
           setTimeout(function(){
               $('#ddlSubCategory').val(s.subCategoryId);
           },500);
           $('#txtName').val(s.productName);
           $('#txtDescription').val(s.description);
           $('#txtPrice').val(s.price);
           $('#txtId').val(s.id);
           $('#btnProduct').val("Update");
       }
    });
}
function viewProduct(id) {
    $('#productModal').modal();
    $.ajax({
       url: "process/product.php",
       type: "POST",
       data:{VIEW_ID:id},
       dataType: "JSON",
       success: function(s){
           $('#productImage').attr('src',s.image);
           $('#productId').text("Pro - "+s.id);
           $('#productName').text(s.productName);
           $('#subCat').text(s.SubCat);
           $('#productDescription').html(s.description);
           $('#productPrice').text(s.price);
           $('#date').text(s.date);
           $('#time').text(s.time);
       }
    });
}
function resetCkEditor(){
    for(instance in CKEDITOR.instances) {
        CKEDITOR.instances[instance].setData("");
    }
}