$(document).ready(function(){
    $('#catForm').on('submit',function(e){
        e.preventDefault();
        $.ajax({
            url: "process/category.php",
            type: "POST",
            data: new FormData(this),
            processData: false,
            contentType: false,
            beforeSend: function(){
                $('#loader').show();
            },
            success: function(s){
                s = $.trim(s);
                if(s=="1"){
                    $('#error').html("<p class='alert alert-success'>Successfully Saved!</p>");
                    catForm.reset();
                    setTimeout(function(){
                        $('#error').html(s);
                    },1500);
                }else if(s=="2"){
                    $('#error').html("<p class='alert alert-success'>Successfully Updated!</p>");
                    catForm.reset();
                    $('#txtId').val("");
                    setTimeout(function(){
                        $('#error').html("");
                    },1500);
                    $('#btnCat').val("Save");
                }else{
                    $('#error').html("");
                }
            },
            complete: function () {
                $('#loader').hide();
                loadAllCategories();
            }
        });
    });
    loadAllCategories();
});
function loadAllCategories(){
    $.ajax({
        url: "process/category.php",
        type: "GET",
        data:{
            LIMIT: $('#txtLimit').val(),
            ORDER: $('#txtOrderBy').val(),
            SEARCH: $('#txtSearch').val()
        },
        beforeSend: function(){
            $('#ldr').show();
        },
        success: function(s){
            $('#listCategories').html(s);
        },
        complete: function(){
            $('#ldr').hide();
        }
    });
}
function editCategory(id){
    $.ajax({
        url: "process/category.php",
        type: "POST",
        data: {ID:id},
        dataType: "JSON",
        success: function(s){
            $('#txtId').val(s.id);
            $('#txtName').val(s.name);
            $('#btnCat').val("Update");
        }
    });
}
function deleteCategory(id){
    /*swal({
            title: 'Are You Sure You Want To Delete?',
            text: 'It Can not be undone',
            type: 'warning',
            showCancelButton: true,
            confirmButtonClass: 'btn-outline-success',
            confirmButtonText: 'Yes',
            cancelButtonText: 'No',
            closeOnConfirm: false,
            closeOnCancel: false,
        },
        function(isConfirm) {
            if (isConfirm) {
                $.ajax({
                   url: "process/category.php",
                   type: "POST",
                   data:{DELETE_ID:id},
                   success:function(s){
                       s=$.trim(s);
                      if(s=="1"){
                          swal({
                              title: 'Success',
                              text:'Successfully Deleted!',
                              type: 'success'
                          });
                      }else{
                          swal({
                              title: 'Error',
                              text:'Something Went Wrong!',
                              type: 'error'
                          });
                      }
                   }
                });
            }
        });*/
}