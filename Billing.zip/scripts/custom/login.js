$(document).ready(function(){
    $('#loginForm').on('submit',function(e){
       e.preventDefault();
        $.ajax({
            url: "process/login.php",
            type: "POST",
            data: new FormData(this),
            processData: false,
            contentType: false,
            beforeSend: function(){
                $('#loader').show();
            },
            success: function (s) {
                s= $.trim(s);
                if(s=="1"){
                    document.location="Dashboard";
                }else{
                    $('#error').html(s);
                }
            },
            complete: function(){
                $('#loader').hide();
                loadCaptcha();
            }
        });
    });
loadCaptcha();
});
function loadCaptcha(){
    $.post("images/botImage.php",{},function(s){
       s = $.trim(s);
       $('#captcha').html(s);
    });
}