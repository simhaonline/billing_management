$(document).ready(function(){
    loadAllOrders();
});
function loadAllOrders(){
    $.ajax({
        url: "process/orders.php",
        type: "GET",
        data:{
            LIMIT: $('#txtLimit').val(),
            ORDER: $('#txtOrder').val(),
            SEARCH: $('#txtSearch').val(),
            CUST_ID: $('#txtCustomer').val(),
            STATUS: $('#txtStatus').val()
        },
        beforeSend: function(){
            $('#ldr').show();
        },
        success: function(s){
            $('#listOrders').html(s);
        },
        complete: function () {
            $('#ldr').hide();
        }
    });
}
function editOrder(id){
    $('#orderModal').modal();
    $.ajax({
       url: "process/orders.php",
       type: "GET",
       data:{EDIT_ID:id},
       success: function(s){
           s = $.trim(s);
           $('#modalData').html(s);
       }
    });
}
function editData(){
    var discount = $('#txtDiscount').val(),
        status = $('#txtStatus1').val(),
        pdid = $('#txtEditId').val();
    $.ajax({
        url: "process/orders.php",
        type: "POST",
        data:{
            DISCOUNT: discount,
            STATUS1:status,
            PDID: pdid
        },
        beforeSend: function(){
            $('#btnUpdateOrder').val("Updatng...");
        },
        success: function(s){
            s = $.trim(s);
            if(s=="1"){
                $('#orderModal').modal("toggle");
                loadAllOrders();
            }else{
                $('#editError').html(s);
            }
        },
        complete: function(){
            $('#btnUpdateOrder').val("Update");
        }
    });
    return false;
}
function viewOrder(id){
    $('#orderModal').modal();
    $.ajax({
        url: "process/orders.php",
        type: "GET",
        data:{VIEW_ID:id},
        success: function(s){
            s = $.trim(s);
            $('#modalData').html(s);
        }
    });
}