$(document).ready(function(){
    $('#custForm').on('submit',function(e){
       e.preventDefault();
       $.ajax({
           url: "process/customers.php",
           type: "POST",
           data: new FormData(this),
           processData: false,
           contentType: false,
           beforeSend: function(){
               $('#loader').show();
           },
           success: function(s){
               s = $.trim(s);
               if(s=="1"){
                   $('#error').html("<p class='alert alert-success'>Successfully Saved!</p>");
                   custForm.reset();
                   setTimeout(function(){
                       $('#error').html("");
                   },1500);
               }else if(s=="2"){
                   $('#error').html("<p class='alert alert-success'>Successfully Updated!</p>");
                   custForm.reset();
                   $('#txtId').val("");
                   $('#btnCust').val("Save");
                   setTimeout(function(){
                       $('#error').html("");
                   },1500);
               }else{
                   $('#error').html(s);
               }
           },
           complete: function () {
               $('#loader').hide();
               loadAllCustomers();
           }
       });
    });
    loadAllCustomers();
});
function loadAllCustomers(){
    $.ajax({
        url: "process/customers.php",
        type: "GET",
        data:{
            LIMIT: $('#txtLimit').val(),
            ORDER: $('#txtOrder').val(),
            SEARCH: $('#txtSearch').val()
        },
        beforeSend: function () {
            $('#ldr').show();
        },
        success: function(s){
            s = $.trim(s);
            $('#listCustomers').html(s);
        },
        complete: function () {
            $('#ldr').hide();
        }
    });
}
function editCustomer(id){
    $.ajax({
       url: "process/customers.php",
       type: "POST",
       data: {ID:id},
       dataType: "JSON",
       success: function(s){
           $('#txtId').val(s.id);
           $('#txtName').val(s.name);
           $('#txtMobile').val(s.mobileNumber);
           $('#txtEmail').val(s.email);
           $('#txtAddress').val(s.address);
           $('#btnCust').val("Update");
       }
    });
}
function viewCustomer(id){
    $('#custModel').modal();
    $.ajax({
        url: "process/customers.php",
        type: "POST",
        data: {VIEW_ID:id},
        dataType: "JSON",
        success: function(s){
            $('#txtCustId').text("CUST - "+s.id);
            $('#txtCustName').text(s.name);
            $('#txtCustMobile').text(s.mobileNumber);
            $('#txtCustEmail').text(s.email);
            $('#txtCustAddress').text(s.address);
        }
    });
}