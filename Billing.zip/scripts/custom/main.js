$(document).ready(function(){
    $('.topNav').on('click',function(e){
       e.stopPropagation();
       $(this).children('.navigation').slideToggle();
    });
    getData();
});
function getData(){
    $.ajax({
       url: "process/getData.php",
       type: "GET",
       data: {},
       dataType: "JSON",
       success: function(s){
           if(s.image==""){
               $('#userImage').attr('src',"images/avatar.png");
           }else{
               $('#userImage').attr('src',s.image);
           }
           $('#userName').text(s.name);
       }
    });
}
function changePassword(){
    $.ajax({
       url: "process/changePassword.php",
       type: "POST",
       data:{
         OLD_PASSWORD: $('#txtOPassword').val(),
         PASSWORD : $('#txtPassword').val(),
         C_PASSWORD: $('#txtCPassword').val()
       },
       beforeSend: function(){
           $('#loader').show();
       },
       success: function(s){
            s = $.trim(s);
            if(s=="1"){
                $('#error').html("<p class='alert alert-success'>Successfully Changed!</p>");
                setTimeout(function(){
                    $('#error').html("");
                    $('#modalPassword').modal("toggle");
                },1500);
                $('#txtOPassword').val("");
                $('#txtCPassword').val("");
                $('#txtPassword').val("");
            }else{
                $('#error').html(s);
            }
       },
       complete: function(){
           $('#loader').hide();
       }
    });
    return false;
}