id="";gAmount=0;
$(document).ready(function(){
    $('#orderForm').on('submit',function(e){
        e.preventDefault();
        $.ajax({
           url: "process/addData.php",
           type: "POST",
           data: new FormData(this),
           processData: false,
           contentType: false,
           beforeSend: function(){
               $('#loader').show();
           },
           success: function(s){
               s = $.trim(s);
               $('#error').html("<p class='alert alert-success'>Successfully Placed!" +
                   "<a href='Manage_Orders/'> Click Here!</a> To Manage!" +
                   " </p>");
               orderForm.reset();
           },
           complete: function(){
               $('#loader').hide();
           }
        });
    });
 addData();
 getGAmount();
});
function addData(){
    if(isNaN(id)){
        id=0;
    }else{
        id++;
    }
    $.ajax({
       url: "process/addData.php",
       type: "GET",
       data:{COUNT:id},
       success: function (s) {
           s = $.trim(s);
           $('#pData').append(s);
       }
    });
}
function removeTr(id){
    $('#pData').children("#tr_"+id).remove();
    getGAmount();
}
function getProductData(id){
    var pdId = $('#product_'+id).val();
    $.ajax({
        url: "process/addData.php",
        type: "POST",
        data:{PROD_ID:pdId},
        dataType: "JSON",
        success: function(s){
            $('#qty_'+id).val(1);
            $('#rate_'+id).val(s.price);
            $('#amount_'+id).val(s.price*$('#qty_'+id).val());
        },
        complete: function(){
            getGAmount();
        }
    });
}
function getTotal(id){
    var t = $('#rate_'+id).val()*$('#qty_'+id).val();
    $('#amount_'+id).val(t);
    getGAmount();
}
function getGAmount(){
    var totalAmount=0;
    var tableProductLength = $("#product_table tbody tr").length;
    var totalSubAmount = 0;
    for(x = 0; x < tableProductLength; x++) {
        id++;
        var tr = $("#product_table tbody tr")[x];
        var count = $(tr).attr('id');
        count = count.substring(3);
        totalSubAmount = Number(totalSubAmount) + Number($("#amount_"+count).val());
    } // /for

    totalSubAmount = totalSubAmount.toFixed(2);
    $('#txtGrossAmount').val(totalSubAmount);

    var gstTotal = $('#txtGrossAmount').val()*(18/100);
    $('#txtGst').val(gstTotal);

    var discount = $('#txtDiscount').val();
    var t = $('#txtGrossAmount').val();
    totalAmount = Number(parseInt(t) + parseInt($('#txtGst').val()));
    if(discount){
        totalAmount = Number(totalAmount - discount);
    }
    totalAmount = totalAmount.toFixed(2);
    $('#txtNet').val(totalAmount);
}