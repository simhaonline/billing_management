$(document).ready(function(){
    $('#imageUser').hide();
    $('#userForm').on('submit',function(e){
       e.preventDefault();
        $.ajax({
           url: "process/registration.php",
           type: "POST",
           data: new FormData(this),
           processData: false,
           contentType: false,
           beforeSend: function(){
            $('#loader').show();
           },
           success: function(s){
            s = $.trim(s);
            if(s=="1"){
                $('#error').html("<p class='alert alert-success'>Successfully Saved!</p>");
                userForm.reset();
                getData();
                setTimeout(function(){
                    $('#error').html("");
                },1500);
            }else if(s=="2"){
                $('#error').html("<p class='alert alert-success'>Successfully Updated!</p>");
                $('#txtId').val("");
                $('#btnUser').val("Save");
                $('#imageUser').removeAttr('src').hide();
                userForm.reset();
                getData();
                setTimeout(function(){
                    $('#error').html("");
                },1500);
            }else{
                $('#error').html(s);
            }
           },
           complete: function(){
               $('#loader').hide();
               loadAllUsers();
               getData();
           }
        });
    });
    loadAllUsers();
});
function loadAllUsers(){
    $.ajax({
        url: "process/registration.php",
        type: "GET",
        data:{
            LIMIT: $('#txtLimit').val(),
            ORDER: $('#txtOrder').val(),
            SEARCH: $('#txtSearch').val(),
            ROLE: $('#ddlRole').val(),
            STATUS:$('#ddlStatus').val()
        },
        beforeSend: function(){
            $('#ldr').show();
        },
        success: function(s){
            s = $.trim(s);
            $('#listUsers').html(s);
        },
        complete: function(){
            $('#ldr').hide();
        }
    });
}
function editUser(id){
    $.ajax({
       url: "process/registration.php",
       type: "POST",
       data:{ID:id},
       dataType: "JSON",
       success: function(s){
           if(s.image !== "" || s.image != null) {
               $('#imageUser').attr('src',s.image).addClass('img-circle img-thumbnail').show();
           }
            $('#txtId').val(s.id);
            $('#txtName').val(s.name);
            $('#txtEmail').val(s.email);
            $('#txtMobile').val(s.mobile);
            $('#txtUsername').val(s.username);
            $('#txtRole').val(s.roleId);
            $('#txtStatus').val(s.status);
            $('#btnUser').val("Update");
       }
    });
}
function viewUser(id){
    $('#userModal').modal();
    $.ajax({
        url: "process/registration.php",
        type: "POST",
        data:{ID:id},
        dataType: "JSON",
        success: function(s){
            if(s.image !== "" || s.image != null) {
                $('#modalUserImage').attr('src',s.image).show();
            }
            $('#txtModalName').text(s.name);
            $('#txtModalUsername').text(s.username);
            $('#txtModalEmail').text(s.email);
            $('#txtModalMobile').text(s.mobile);
            switch(s.status){
                case '1':
                    $('#txtModalStatus').html("<span class='text-success'><i class='fa fa-check'></i> Active</span>");
                break;
                case '2':
                    $('#txtModalStatus').html("<span class='text-danger'><i class='fa fa-times'></i> InActive</span>");
                break;
                default:
                    $('#txtModalStatus').html("");
                break;
            }
        }
    });
}