$(document).ready(function(){
   $('#compForm').on('submit',function(e){
      e.preventDefault();
      $.ajax({
         url: "process/company.php",
         type: "POST",
         data: new FormData(this),
         processData: false,
         contentType: false,
         beforeSend: function () {
             $('#loader').show();
         },
         success:function (s) {
             s = $.trim(s);
             if(s=="1"){
                $('#error').html("<p class='alert alert-success'>Successfully Saved!</p>");
                compForm.reset();
                setTimeout(function(){
                    $('#error').html("");
                },1500);
             }else if(s=="2"){
                 $('#error').html("<p class='alert alert-success'>Successfully Updated!</p>");
                 compForm.reset();
                 $('#btnComp').val("Save");
                 setTimeout(function(){
                     $('#error').html("");
                 },1500);
             }else{
                 $('#error').html(s);
             }
         },
         complete: function () {
             $('#loader').hide();
             getDetails();
         }
      });
   });
   getDetails();
});
function getDetails(){
    $.ajax({
       url: "process/company.php",
       type: "GET",
       dataType: "JSON",
       success: function(s){
           if(s.logo!=""){
                $('#imageLogo').attr('src',s.logo);
           }else{
                $('#imageLogo').hide();
           }
          $('#txtId').val(s.id);
          $('#txtName').val(s.name);
          $('#txtMobile').val(s.mobile);
          $('#txtEmail').val(s.email);
          $('#txtAddressLine1').val(s.addressLine1);
          $('#txtAddressLine2').val(s.addressLine2);
          $('#txtLandmark').val(s.landmark);
          $('#txtDistrict').val(s.district);
          $('#txtState').val(s.state);
          $('#txtCountry').val(s.country);
          $('#txtPin').val(s.pin);
          $('#txtGst').val(s.gstin);
          $('#btnComp').val("Update");
       }
    });
}