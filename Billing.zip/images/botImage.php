<?php
	if($_SERVER['REQUEST_METHOD']=="POST"){
	header('Content-type: image/png');
    $text= "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
    $text=substr(str_shuffle($text),0,6);
    session_start();
    $_SESSION['botText']=$text;
?>
<img src="images/generateCaptcha.php" id="captchaImg"/>
<?php
}
?>